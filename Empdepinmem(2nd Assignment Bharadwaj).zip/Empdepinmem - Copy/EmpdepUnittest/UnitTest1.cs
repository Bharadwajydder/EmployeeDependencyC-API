// <copyright file="UnitTest1.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace EmpdepUnittest
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using EmployeeDependency.Controllers;
    using EmployeeDependency.Data;
    using EmployeeDependency.Dependency;
    using EmployeeDependency.Model;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using Xunit;

    /// <summary>
    /// The name of the Class  used to implement methods of test cases.
    /// </summary>
    public class UnitTest1
    {
        private readonly EmployeeController emp;

        private readonly Mock<IEmployeedi> employeemock = new Mock<IEmployeedi>();

        /// <summary>
        /// Initializes a new instance of the <see cref="UnitTest1"/> class.
        /// The name of the Class  used to implement methods by using Interface.
        /// </summary>
        public UnitTest1() => this.emp = new EmployeeController(this.employeemock.Object);

        /// <summary>
        /// The name of the GetCategoriesbyId used to implement methods.
        /// </summary>
        /// <returns>
        /// The List of single Employee.
        /// </returns>
        [Fact]
        public async Task GetEmployee_ById()
        {
            var id = 10;
            var employee1 = new Employee
            {
                Id = id,
                Did = 20,
                Ename = "lion",
                Salary = 1000,
            };
            this.employeemock.Setup(x => x.GetPost(id)).ReturnsAsync(employee1);

            var employee2 = await this.emp.GetPost(id);

            Assert.Equal(id, employee2.Id);
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <returns>
        /// The List of Employees.
        /// </returns>
        [Fact]
        public async Task GetAllEmployee()
        {
            var employees = new List<Employee>()
            {
                new Employee { Id = 1, Did = 10, Ename = "lion", Salary = 10000 },
                new Employee { Id = 2, Did = 20, Ename = "ion", Salary = 20000 },
                new Employee { Id = 3, Did = 30, Ename = "lon", Salary = 30000 },
                new Employee { Id = 4, Did = 40, Ename = "lio", Salary = 40000 },
                new Employee { Id = 5, Did = 50, Ename = "lin", Salary = 50000 },
            };
            this.employeemock.Setup(x => x.GetCategories()).ReturnsAsync(employees);

            var actual = await this.emp.GetCategories();

            Assert.Equal(employees, actual);
        }

        /// <summary>
        /// The name of the Addemployee used to implement methods.
        /// </summary>
        /// <returns>
        /// Add to List of Employees.
        /// </returns>
        [Fact]
        public async Task AddEmployee()
        {
            var employees = new List<Employee>()
            {
                new Employee { Id = 1, Did = 10, Ename = "lion", Salary = 10000 },
                new Employee { Id = 2, Did = 20, Ename = "ion", Salary = 20000 },
                new Employee { Id = 3, Did = 30, Ename = "lon", Salary = 30000 },
                new Employee { Id = 4, Did = 40, Ename = "lio", Salary = 40000 },
                new Employee { Id = 5, Did = 50, Ename = "lin", Salary = 50000 },
            };
            Employee employee1 = new Employee
            {
                Id = 100,
                Did = 200,
                Ename = "lion",
                Salary = 10000,
            };

            this.employeemock.Setup(x => x.AddPost(employee1)).ReturnsAsync(employee1.Id);

            var actual = await this.emp.AddPost(employee1);

            Assert.Equal(100, actual);
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <returns>
        /// Delete from List of Employees.
        /// </returns>
        [Fact]
        public async Task DeleteEmployee()
        {
            var id = 10;
            var employee1 = new Employee
            {
                Id = id,
                Did = 20,
                Ename = "lion",
                Salary = 1000,
            };
            this.employeemock.Setup(x => x.DeletePost(id)).ReturnsAsync(-1);

            var actual = await this.emp.DeletePost(10);

            Assert.Equal(-1, actual);
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <returns>
        /// Update List of Employees.
        /// </returns>
        [Fact]
        public async Task UpdateEmployee()
        {
            var employee1 = new Employee
            {
                Id = 10,
                Did = 20,
                Ename = "lion",
                Salary = 1000,
            };
            var employee2 = new Employee
            {
                Id = 10,
                Did = 22,
                Ename = "lion",
                Salary = 1100,
            };
            this.employeemock.Setup(x => x.UpdatePost(employee1.Id, employee2)).ReturnsAsync(employee2.Id);

            var actual = await this.emp.PutEmployee(employee1.Id, employee2);

            Assert.Equal(actual, employee2.Id);
        }
    }
}
