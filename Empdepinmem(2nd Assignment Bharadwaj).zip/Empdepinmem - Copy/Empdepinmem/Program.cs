// <copyright file="Program.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Empdepinmem
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// The name of the Class  used to implement methods by using Interface.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// The name of the Class  used to implement methods by using Interface.
        /// </summary>
        /// <param name="args">Normal args parameter. </param>
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        /// <summary>
        /// The name of the Class  used to implement methods by using Interface.
        /// </summary>
        /// <param name="args">normal args parameter. </param>
        /// <returns>
        /// Returns the IHostBuilder.
        /// </returns>
        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
.ConfigureWebHostDefaults(webBuilder =>
{
webBuilder.UseStartup<Startup>();
});
        }
    }
}
