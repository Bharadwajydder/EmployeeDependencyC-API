// <copyright file="Startup.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Empdepinmem
{
    using System;
    using Castle.Facilities.AspNetCore;
    using Castle.MicroKernel.Registration;
    using Castle.Windsor;
    using Castle.Windsor.Installer;
    using Castle.Windsor.MsDependencyInjection;
    using EmployeeDependency.Data;
    using EmployeeDependency.Dependency;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.OpenApi.Models;
    using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

    /// <summary>
    /// The name of the Class  used to implement methods by using Interface.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// The name of the Class  used to implement methods by using Interface.
        /// </summary>
        /// <param name="configuration">IConfiguration parameter. </param>
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        /// <summary>
        /// Gets the name of the Class  used to implement methods by using Interface.
        /// </summary>
        /// <returns>
        /// <see cref="object"/>.
        /// </returns>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <param name="services">IServiceCollection parameter. </param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddDbContext<EmpContext>(opt =>
                                               opt.UseInMemoryDatabase("Emplist"));

            services.AddScoped<IEmployeedi, Employeedi>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Empdepinmem", Version = "v1" });
            });
        }

        /// <summary>
        ///  This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"> IApplicationBuilder parameter. </param>
        /// <param name="env"> IWebHostEnvironment parameter. </param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Empdepinmem v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
