﻿// <copyright file="EmployeeController.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
namespace EmployeeDependency.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EmployeeDependency.Dependency;
    using EmployeeDependency.Model;
    using Microsoft.AspNetCore.Mvc;

    /// <summary>
    /// The name of the Controller used to implement methods.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        /// <summary>
        /// The name of the Controller used to implement methods.
        /// </summary>
        /// <param name="context">context of interface used in constructor. </param>
        private readonly IEmployeedi context;

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeController"/> class.
        /// The name of the Controller used to implement methods.
        /// </summary>
        /// <param name="context">context of interface used in constructor. </param>
        public EmployeeController(IEmployeedi context)
        {
            this.context = context;
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <returns>
        /// The List of Employees.
        /// </returns>
        // GET: api/<EmployeeController>
        [HttpGet]
        public async Task<List<Employee>> GetCategories()
        {
            try
            {
                var categories = await this.context.GetCategories();
                if (categories == null)
                {
                    return null;
                }

                return categories;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// The name of the GetPost  methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>
        /// The List of Employee.
        /// </returns>
        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        public async Task<Employee> GetPost(int id)
        {
            if (id == null)
            {
                return null;
            }

            var post = await this.context.GetPost(id);

            if (post == null)
                {
                    return null;
                }

            return post;
        }

        /// <summary>
        /// The name of the AddPost method.
        /// </summary>
        /// <param name="model">Employee type model parameter. </param>
        /// <returns>
        /// integer.
        /// </returns>
        // POST api/<EmployeeController>
        [HttpPost]
        public async Task<int> AddPost([FromBody] Employee model)
        {
            if (this.ModelState.IsValid)
            {
                 var postId = await this.context.AddPost(model);
                 if (postId > 0)
                    {
                        return postId;
                    }
                    else
                    {
                        return 0;
                    }
            }

            return 0;
        }

        /// <summary>
        /// The name of the putEmployee methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <param name="customer">Employee type model parameter. </param>
        /// <returns>
        /// integer .
        /// </returns>
        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        public async Task<int> PutEmployee([FromRoute] int id, [FromBody] Employee customer)
        {
            if (id != customer.Id)
            {
                return 0;
            }

            if (!this.ModelState.IsValid)
            {
                return 0;
            }

            var result = await this.context.UpdatePost(id, customer);

            return result;
        }

        /// <summary>
        /// The name of the Delete  methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>
        /// integer.
        /// </returns>
        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public async Task<int> DeletePost(int id)
        {
            int result = 0;

            if (id == null)
            {
                return result;
            }

            try
            {
                result = await this.context.DeletePost(id);
                if (result == 0)
                {
                    return result;
                }

                return result;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
