﻿// <copyright file="Employeedi.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace EmployeeDependency.Dependency
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using EmployeeDependency.Data;
    using EmployeeDependency.Model;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// The name of the Class  used to implement methods by using Interface.
    /// </summary>
    public class Employeedi : IEmployeedi
    {
        /// <summary>
        /// The name of the Context used to implement methods.
        /// </summary>
        private readonly EmpContext context;

        /// <summary>
        /// Initializes a new instance of the <see cref="Employeedi"/> class.
        /// The name of the Constructor used to implement methods.
        /// </summary>
        /// <param name="context">integer type EmployeeID parameter. </param>
        public Employeedi(EmpContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <param name="employee">integer type EmployeeID parameter. </param>
        /// <returns>
        /// The List of Employees.
        /// </returns>
        public async Task<int> AddPost(Employee employee)
        {
            await this.context.Employees.AddAsync(employee);

            await this.context.SaveChangesAsync();

            return employee.Id;

            // throw new NotImplementedException();
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>
        /// The List of Employees.
        /// </returns>
        public async Task<int> DeletePost(int id)
        {
            int result = 0;
            if (this.context != null)
            {
                var post = await this.context.Employees.FirstOrDefaultAsync(x => x.Id == id);

                if (post != null)
                {
                    // Delete that post
                    this.context.Employees.Remove(post);

                    // Commit the transaction
                    await this.context.SaveChangesAsync();

                    result = -1;
                }

                return result;
            }

            return result;
        }

        /// <summary>
        /// The name of the GetCategories used to implement methods.
        /// </summary>
        /// <returns>
        /// The List of Employees.
        /// </returns>
        public async Task<List<Employee>> GetCategories()
        {
            if (this.context != null)
            {
                return await this.context.Employees.ToListAsync();
            }

            return null;
        }

        /// <summary>
        /// The name of the GetPost used to implement methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>
        /// The Specific of Employee.
        /// </returns>
        public async Task<Employee> GetPost(int id)
        {
            var customer = await this.context.Employees.SingleOrDefaultAsync(m => m.Id == id);
            if (customer != null)
            {
                return customer;
            }

            return null;

            // throw new NotImplementedException();
        }

        /// <summary>
        /// The name of the UpdatePost used to implement methods.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <param name="employee">integer  EmployeeID parameter. </param>
        /// <returns>
        /// The Update of Employees.
        /// </returns>
        public async Task<int> UpdatePost(int id, Employee employee)
        {
            var post = await this.context.Employees.FirstOrDefaultAsync(x => x.Id == id);

            post.Id = employee.Id;
            post.Did = employee.Did;
            post.Ename = employee.Ename;
            post.Salary = employee.Salary;

            this.context.Employees.Update(post);
            await this.context.SaveChangesAsync();

            return post.Id;
        }
    }
}
