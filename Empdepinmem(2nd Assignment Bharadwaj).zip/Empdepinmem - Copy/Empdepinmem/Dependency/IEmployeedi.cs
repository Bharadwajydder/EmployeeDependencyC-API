﻿// <copyright file="IEmployeedi.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace EmployeeDependency.Dependency
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using EmployeeDependency.Model;

    /// <summary>
    /// The name of the Class  used to implement methods by using Interface.
    /// </summary>
    public interface IEmployeedi
    {
        /// <summary>
        /// The name of the method  used to implement  GetEmployee List through Interface.
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        Task<List<Employee>> GetCategories();

        /// <summary>
        /// The name of the method  used to implement  GetEmployee by id through Interface.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        Task<Employee> GetPost(int id);

        /// <summary>
        /// The name of the method  used to implement  Add Employee through Interface..
        /// </summary>
        /// <param name="employee">integer type EmployeeID parameter. </param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        Task<int> AddPost(Employee employee);

        /// <summary>
        /// The name of the method  used to implement  DeleteEmployee  through Interface.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        Task<int> DeletePost(int id);

        /// <summary>
        /// The name of the method  used to implement  UpdateEmployee List through Interface.
        /// </summary>
        /// <param name="id">integer type EmployeeID parameter. </param>
        /// <param name="employee">Employee type model parameter. </param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        Task<int> UpdatePost(int id, Employee employee);
    }
}
