﻿// <copyright file="EmpContext.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace EmployeeDependency.Data
{
    using EmployeeDependency.Model;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// The name of the Context used to implement methods.
    /// </summary>
    public class EmpContext : DbContext
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EmpContext"/> class.
        /// The name of the Context used for Dbcontext methods.
        /// </summary>
        /// <param name="options">Dbcontext type options parameter. </param>
        public EmpContext(DbContextOptions<EmpContext> options)
            : base(options)
        {
        }

        /// <summary>
        /// Gets or sets the name of the Model used to implement methods.
        /// </summary>
        public DbSet<Employee> Employees { get; set; }
    }
}
