﻿// <copyright file="Employee.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace EmployeeDependency.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// The name of the Class  used to implement methods by using Interface.
    /// </summary>
    public class Employee
    {
        /// <summary>
        /// Gets or sets the name of the Class  used to implement methods by using Interface.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the Class  used to implement methods by using Interface.
        /// </summary>
        public int Did { get; set; }

        /// <summary>
        /// Gets or sets the name of the Class  used to implement methods by using Interface.
        /// </summary>
        public string Ename { get; set; }

        /// <summary>
        /// Gets or sets the name of the Class  used to implement methods by using Interface.
        /// </summary>
        public int Salary { get; set; }
    }
}
